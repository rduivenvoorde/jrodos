
# set API to version 2
# TODO python 3: remove
import qgis

from .setting_manager import SettingManager
from .setting import Setting, Scope
from .setting_dialog import SettingDialog, UpdateMode
#from .types import bool.Bool, String, Integer, Color, Double



